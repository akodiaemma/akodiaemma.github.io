#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

try {
  const args = process.argv.slice(2);
  if (args.length < 1 || args.length > 2 || (args[1] && args[1] !== '--write')) {
    throw new Error('Usage: node apply-stiv-courtesy.cjs /path/to/backend [--write]');
  }
  const repo = fs.realpathSync(args[0]);
  const write = args[1] === '--write';
  const plan = JSON.parse(fs.readFileSync(path.join(__dirname, 'changes.json'), 'utf8'));
  const pending = [];
  const normalise = (text) => text.replace(/\r\n/g, '\n');
  const occurrences = (text, value) => text.split(value).length - 1;
  const resolve = (relative) => {
    const result = path.resolve(repo, relative);
    if (!result.startsWith(repo + path.sep)) throw new Error('Invalid target path');
    return result;
  };

  for (const file of plan.edits) {
    const target = resolve(file.path);
    const original = fs.readFileSync(target, 'utf8');
    let updated = normalise(original);
    for (const change of file.changes) {
      const applied = occurrences(updated, change.after);
      if (applied === 1) continue;
      if (applied > 1 || occurrences(updated, change.before) !== 1) {
        throw new Error(`Cannot safely locate a unique edit in ${file.path}. No changes written.`);
      }
      updated = updated.replace(change.before, () => change.after);
    }
    if (updated !== normalise(original)) {
      pending.push({ target, relative: file.path, original,
        updated: original.includes('\r\n') ? updated.replace(/\n/g, '\r\n') : updated });
    }
  }
  for (const file of plan.newFiles) {
    const target = resolve(file.path);
    if (fs.existsSync(target)) {
      if (normalise(fs.readFileSync(target, 'utf8')) !== normalise(file.content)) {
        throw new Error(`${file.path} already exists with different contents. No changes written.`);
      }
    } else pending.push({ target, relative: file.path, original: null, updated: file.content });
  }
  if (!pending.length) {
    console.log('This STIV courtesy fix is already applied. No files changed.');
    process.exit(0);
  }
  console.log(`${write ? 'Applying' : 'Previewing'} changes to ${pending.length} files:`);
  for (const file of pending) console.log(`  ${file.relative}`);
  if (!write) {
    console.log('No files changed. Add --write to apply the reviewed changes.');
    process.exit(0);
  }
  const backup = fs.mkdtempSync(path.join(os.tmpdir(), 'stiv-courtesy-backup-'));
  for (const file of pending) {
    if (file.original === null) continue;
    const copy = path.join(backup, file.relative);
    fs.mkdirSync(path.dirname(copy), { recursive: true });
    fs.writeFileSync(copy, file.original);
  }
  const written = [];
  try {
    for (const file of pending) {
      fs.mkdirSync(path.dirname(file.target), { recursive: true });
      written.push(file);
      fs.writeFileSync(file.target, file.updated);
    }
  } catch (error) {
    for (const file of written.reverse()) {
      if (file.original === null) fs.rmSync(file.target, { force: true });
      else fs.writeFileSync(file.target, file.original);
    }
    throw error;
  }
  console.log(`Applied. Original changed files are backed up at ${backup}`);
  console.log('Review git diff, build and test, then commit and run the staging deployment.');
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
