/** Only complete, harmless social messages qualify. Never use a prefix match. */
export type CourtesyKind = 'greeting' | 'checkin' | 'thanks' | 'well' | 'difficult' | 'identity' | 'goodbye';

const phrases: Record<CourtesyKind, string[]> = {
  greeting: ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'bonjour', 'salut', 'bonsoir', 'habari', 'hujambo', 'jambo', 'oli otya'],
  checkin: ['how are you', 'how are you doing', 'how are you today', 'how is your day', "how's your day", 'how was your day', 'how was your day today', 'and you', 'what about you', 'comment ça va', 'comment vas-tu', 'ça va', 'et toi', 'habari yako', 'unaendeleaje', 'na wewe'],
  thanks: ['thanks', 'thank you', 'thanks a lot', 'thank you very much', 'merci', 'merci beaucoup', 'asante', 'asante sana', 'webale', 'weebale', 'webale nnyo', 'weebale nnyo'],
  well: ["i'm fine", 'i am fine', "i'm good", 'i am good', "i'm doing well", 'i am doing well', "i'm fine thanks", "i'm good thanks", 'i am fine thank you', 'my day was good', 'my day is going well', 'je vais bien', 'niko vizuri', 'niko salama', 'ndi bulungi'],
  difficult: ["i'm having a difficult day", 'i am having a difficult day', "i've had a difficult day", 'my day was difficult', 'i had a bad day', "i'm frustrated", 'i am frustrated'],
  identity: ['who are you', 'what is your name', "what's your name", 'what can i call you', 'how can i call you', "comment t'appelles-tu", 'unaitwa nani', 'erinnya lyo gwe ani'],
  goodbye: ['bye', 'goodbye', 'bye bye', 'see you', 'see you later', 'good night', 'au revoir', 'à bientôt', 'kwaheri', 'weraba'],
};

function normalise(message: string): string {
  return message.normalize('NFKC').toLowerCase().replace(/[’‘]/g, "'")
    .replace(/[.,!?]/g, ' ').replace(/\s+/g, ' ').trim();
}

const exactPhrases = new Map<string, CourtesyKind>();
for (const [kind, values] of Object.entries(phrases)) {
  for (const value of values) {
    for (const name of ['', ' stiv', ' steve']) {
      exactPhrases.set(normalise(value + name), kind as CourtesyKind);
    }
  }
}

export function matchCourtesy(message: string): CourtesyKind | null {
  // Check the entire input before normalising; never silently discard a tail.
  if (!message || message.length > 200) return null;
  const text = normalise(message);
  const direct = exactPhrases.get(text);
  if (direct) return direct;
  // "Hi STIV, how are you?" is courteous; "Hi STIV, approve my documents" is not.
  for (const greeting of phrases.greeting) {
    for (const name of ['', ' stiv', ' steve']) {
      const prefix = normalise(greeting + name) + ' ';
      if (text.startsWith(prefix)) {
        const followup = exactPhrases.get(text.slice(prefix.length));
        if (followup && followup !== 'greeting') return followup;
      }
    }
  }
  return null;
}

function safeFirstName(value?: string | null): string {
  const first = (value ?? '').trim().split(/\s+/)[0];
  if (!first || first.length > 40 || first.length < 2 ||
      !/^[\p{L}\p{M}'’-]+$/u.test(first) || /^(admin|user|test|none|unknown)$/i.test(first)) return '';
  return `, ${first}`;
}

export function courtesyReply(kind: CourtesyKind, input: {
  language: string;
  preferredName?: string | null;
  /** True only when an owned user message exists in a different session. */
  returning: boolean;
  /** Already conversed in this session; avoid repeated welcome-back/name. */
  continuing: boolean;
  role?: string;
  guided: boolean;
}): string {
  const name = input.continuing ? '' : safeFirstName(input.preferredName);
  const knownName = !!safeFirstName(input.preferredName);
  const welcomeBack = input.returning && !input.continuing;
  const enInvite = input.guided
    ? 'We can continue your onboarding whenever you are ready.'
    : input.role === 'ADMIN'
      ? 'What would you like help with in your administration workspace today?'
      : input.role === 'BUYER'
        ? 'What would you like help sourcing or working on today?'
        : 'What would you like help with in your trade work today?';
  const en: Record<CourtesyKind, string> = {
    greeting: `${welcomeBack ? 'Welcome back' : input.continuing ? 'Hi again' : 'Hello'}${name}! ${enInvite}`,
    checkin: "I'm here and ready to help, thanks for asking! How is your day going?",
    thanks: `You're very welcome! ${input.guided ? 'We can continue whenever you are ready.' : 'Let me know if you would like a hand with the next step.'}`,
    well: `Glad to hear it! ${enInvite}`,
    difficult: `I'm sorry it has been a difficult day. We can take things one step at a time. ${enInvite}`,
    identity: `You can call me STIV. I'm Crossgates Connect's AI trade assistant. ${knownName ? enInvite : 'What would you like me to call you?'}`,
    goodbye: 'Take care! I will be here when you need a hand with your trade work.',
  };
  const fr: Record<CourtesyKind, string> = {
    greeting: `${welcomeBack ? 'Bon retour' : 'Bonjour'}${name} ! Comment puis-je vous aider dans votre travail commercial aujourd’hui ?`,
    checkin: 'Je suis là pour vous aider, merci ! Comment se passe votre journée ?',
    thanks: 'Avec plaisir ! Dites-moi si vous souhaitez de l’aide pour la prochaine étape.',
    well: 'Tant mieux ! Sur quoi souhaitez-vous travailler dans votre espace Crossgates ?',
    difficult: 'Je suis désolé que votre journée soit difficile. Nous pouvons avancer étape par étape dans votre travail commercial.',
    identity: 'Vous pouvez m’appeler STIV. Je suis l’assistant commercial IA de Crossgates Connect.' + (knownName ? '' : ' Comment souhaitez-vous que je vous appelle ?'),
    goodbye: 'À bientôt ! Je serai là pour vous aider dans votre travail commercial.',
  };
  const sw: Record<CourtesyKind, string> = {
    greeting: `${welcomeBack ? 'Karibu tena' : 'Habari'}${name}! Nikusaidie nini katika biashara yako leo?`,
    checkin: 'Niko hapa kukusaidia, asante! Siku yako inaendeleaje?',
    thanks: 'Karibu! Niambie ukihitaji msaada kwa hatua inayofuata.',
    well: 'Vizuri! Ungependa tufanye nini katika biashara yako leo?',
    difficult: 'Pole kwa siku ngumu. Tunaweza kushughulikia kazi yako ya biashara hatua kwa hatua.',
    identity: 'Unaweza kuniita STIV. Mimi ni msaidizi wa biashara wa AI wa Crossgates Connect.' + (knownName ? '' : ' Ungependa nikuite nani?'),
    goodbye: 'Kwaheri! Nitakuwa hapa ukihitaji msaada kuhusu biashara yako.',
  };
  const lg: Record<CourtesyKind, string> = {
    greeting: `${welcomeBack ? 'Tukusanyukidde nate' : 'Tukusanyukidde'}${name}! Nkuyambe ntya mu by’obusuubuzi bwo leero?`,
    checkin: 'Ndi wano okukuyamba, weebale! Olunaku lwo lutambula lutya?',
    thanks: 'Kale! Ntegeeza bw’oba weetaaga obuyambi ku mutendera oguddako.',
    well: 'Kirungi! Nkuyambe ntya mu by’obusuubuzi bwo leero?',
    difficult: 'Nsonyiwa olw’olunaku oluzibu. Tusobola okukola ku by’obusuubuzi bwo mutendera ku mutendera.',
    identity: 'Osobola okumpita STIV. Ndi muyambi wa AI ow’ebyobusuubuzi ku Crossgates Connect.' + (knownName ? '' : ' Oyagala nkuyite ani?'),
    goodbye: 'Weraba! Nja kuba wano okukuyamba mu by’obusuubuzi bwo.',
  };
  return ({ en, fr, sw, lg, lug: lg }[input.language] ?? en)[kind];
}
