from pathlib import Path
from playwright.sync_api import sync_playwright
p=Path(__file__).parent
with sync_playwright() as w:
 b=w.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for lang in ['','fr/','de/','sw/','lg/']:
  for width,height in [(1440,900),(390,844)]:
   page=b.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
   errors=[]
   page.on('pageerror',lambda err:errors.append(str(err)))
   page.goto('http://127.0.0.1:8877/'+lang+'index.html',wait_until='domcontentloaded')
   page.wait_for_timeout(400)
   label=(lang.replace('/','') or 'en')+('-desktop' if width>1000 else '-mobile')
   if lang=='':page.screenshot(path=str(p/(label+'.png')),full_page=False)
   values=page.evaluate('''() => ({scrollWidth:document.documentElement.scrollWidth, innerWidth:innerWidth, stiv:!!document.querySelector('.hero-stiv-spotlight'),passport:!!document.querySelector('.hero-passport-intro'),video:document.querySelectorAll('.cg-video-card video').length, stivY:Math.round(document.querySelector('.hero-stiv-spotlight').getBoundingClientRect().top), stivBottom:Math.round(document.querySelector('.hero-stiv-spotlight').getBoundingClientRect().bottom), passportY:Math.round(document.querySelector('.home-passport').getBoundingClientRect().top)})''')
   print(label,values,'errors',errors[:2]);page.close()
 b.close()
