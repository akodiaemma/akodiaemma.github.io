'use strict';
(() => {
 const get=id=>document.getElementById(id);
 const write=(id,text)=>{get(id).textContent=text;};
 const mobile=document.querySelector('.mobile-nav');
 mobile.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{mobile.open=false;}));
 document.addEventListener('keydown',event=>{if(event.key==='Escape'&&mobile.open){mobile.open=false;mobile.querySelector('summary').focus();}});

 const previews={
 business:{kicker:'KNOW THE BUSINESS',title:'Example coffee supplier',labels:['Country','Business details','Registration evidence'],values:['Uganda','Supplied','Review pending'],insight:'See who the supplier is and what still needs checking.'},
 product:{kicker:'UNDERSTAND THE PRODUCT',title:'Green coffee',labels:['Product description','Intended market','Product testing'],values:['Supplied','United Kingdom','Not represented'],insight:'Understand the offering before discussing specifications and samples.'},
 evidence:{kicker:'SEE THE OPEN QUESTIONS',title:'Evidence & next actions',labels:['Registration document','Origin records','Batch history'],values:['Supplied','Missing','Needs evidence'],insight:'Missing information stays visible. Supplied does not mean authenticated.'}
 };
 document.querySelectorAll('[data-preview]').forEach(button=>button.addEventListener('click',()=>{
 const key=button.dataset.preview,p=previews[key];
 document.querySelectorAll('[data-preview]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.preview===key)));
 write('preview-kicker',p.kicker);write('preview-title',p.title);write('preview-insight',p.insight);
 p.labels.forEach((label,i)=>{write('preview-label-'+(i+1),label);write('preview-value-'+(i+1),p.values[i]);});
 }));
 const events=[
  {src:'img/excel-food-expo.webp',width:1086,height:1448,alt:'Doris Beth Atigo at a coffee exhibition stand during a food expo at ExCeL London.',title:'Food expo · ExCeL London',caption:"Gathering market information at ExCeL London and speaking with buyers about what they need from suppliers, as part of the research shaping Crossgates.",credit:''},
  {src:'img/uk-africa-summit.webp',width:2048,height:1366,alt:'Doris Beth Atigo in a red suit among delegates at the UK–Africa Investment Summit.',title:'UK–Africa Investment Summit',caption:"Representing Crossgates and promoting Uganda’s trade potential to an international audience, with conversations about bringing Ugandan businesses to global markets.",credit:'Photograph: © thepromotaAfrica'},
  {src:'img/international-coffee-day.webp',width:1448,height:1086,alt:'Attendees in conversation beside a coffee machine at an International Coffee Day gathering.',title:'International Coffee Day',caption:"Joining Uganda’s coffee community in London for International Coffee Day and conversations around coffee and international trade.",credit:''},
  {src:'img/spitalfields-market.webp',width:1152,height:1536,alt:'Doris Beth Atigo in conversation beside stacked fresh-produce boxes at Spitalfields Market.',title:'Spitalfields Market',caption:"Listening to wholesale buyers and traders about their sourcing needs, the information they expect from suppliers and the practical requirements of the UK market.",credit:''},
{"src": "img/parliament-visit.webp", "width": 1141, "height": 1600, "alt": "Doris Beth Atigo in a green suit with fellow attendees outside Parliament in London.", "title": "House of Lords luncheon", caption:"Attending a luncheon at the House of Lords by invitation, with the opportunity to meet Ugandan ministers and UK government officials and exchange perspectives on UK–Uganda relations.", "credit": ""},
{"src": "img/coffee-exhibition.webp", "width": 1086, "height": 1448, "alt": "Doris Beth Atigo seated with two exhibitors at an Africa Coffee Park exhibition stand.", "title": "Coffee exhibition conversations", caption:"Discussing onboarding, verification and preparation for international markets with coffee buyers and exhibitors at ExCeL London.", "credit": ""},
{"src": "img/spitalfields-produce.webp", "width": 1152, "height": 1536, "alt": "Doris Beth Atigo looking at fresh produce during her Spitalfields Market visit.", "title": "Fresh produce · Spitalfields Market", caption:"Exploring the fresh produce on offer at Spitalfields and gathering first-hand insight into the products and requirements of the UK wholesale market.", "credit": ""}
 ];
 let activeEvent=0;
 const eventButtons=[...document.querySelectorAll('[data-event]')];
 function selectEvent(index,reveal=false){
  activeEvent=(index+events.length)%events.length;
  const item=events[activeEvent];
  eventButtons.forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.event)===activeEvent)));
  const photo=get('event-image');photo.src=item.src;photo.alt=item.alt;photo.width=item.width;photo.height=item.height;
  write('event-title',item.title);write('event-caption',item.caption);write('event-credit',item.credit);get('event-credit').hidden=!item.credit;
  write('event-count',`${activeEvent+1} / ${events.length}`);
  if(reveal){const figure=get('event-view'),rect=figure.getBoundingClientRect();if(rect.bottom<100||rect.top>innerHeight-100)figure.scrollIntoView({block:'start',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});}
 }
 eventButtons.forEach(button=>button.addEventListener('click',()=>selectEvent(Number(button.dataset.event),true)));
 get('event-previous').addEventListener('click',()=>selectEvent(activeEvent-1));
 get('event-next').addEventListener('click',()=>selectEvent(activeEvent+1));
 const roles={supplier:{title:'Build your trade-ready profile.',copy:'Bring your records. Understand the gaps. Prepare a clearer introduction to buyers.',action:'Discuss my business'},buyer:{title:'See what sits behind a supplier’s claims.',copy:'Explore the information, review notes and outstanding questions before deciding your next checks.',action:'Discuss a supplier review'},institution:{title:'See where your businesses need support.',copy:'Understand evidence gaps across your programme and focus readiness support where it is needed.',action:'Discuss my programme'}};
 function selectRole(role){
  if(!roles[role]||!get('audience-action'))return;document.querySelectorAll('[data-role]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.role===role)));
  write('audience-title',roles[role].title);write('audience-copy',roles[role].copy);write('audience-action',roles[role].action);get('audience-action').dataset.audience=role;
  const work={supplier:['suppliers','See our work with suppliers'],buyer:['buyers','Explore our buyer conversations'],institution:['institutions','Explore our institutional engagement']}[role];get('audience-work').href='our-work.html#'+work[0];write('audience-work',work[1]);
 }
 document.querySelectorAll('[data-role]').forEach(button=>button.addEventListener('click',()=>selectRole(button.dataset.role)));
 const roleHashes={'#suppliers':'supplier','#buyers':'buyer','#institutions':'institution'};
 const readRole=()=>{const role=roleHashes[location.hash]||new URLSearchParams(location.search).get('audience');if(role)selectRole(role);};
 window.addEventListener('hashchange',readRole);readRole();
})();
