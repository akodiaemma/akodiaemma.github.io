'use strict';
(() => {
  const names={en:'English',fr:'Français',de:'Deutsch',sw:'Kiswahili',lg:'Luganda'};
  const known=['index','how-it-works','guide','passports','our-work'];
  const parts=location.pathname.split('/').filter(Boolean);
  const locale=Object.hasOwn(names,parts[0])?parts[0]:'en';
  const leaf=parts[parts.length-1]||'index';
  const page=known.includes(leaf.replace(/\.html$/,''))?leaf.replace(/\.html$/,''):'index';
  const read=()=>{try{return localStorage.getItem('crossgates-language')}catch{return null}};
  const save=l=>{try{localStorage.setItem('crossgates-language',l)}catch{}};
  function url(l){const u=new URL((l==='en'?'/':'/'+l+'/')+page+'.html',location.origin);u.search=location.search;u.searchParams.delete('lang');if(l==='en')u.searchParams.set('lang','en');u.hash=location.hash;return u.href;}
  document.querySelectorAll('[data-language]').forEach(a=>{a.href=url(a.dataset.language);a.addEventListener('click',()=>save(a.dataset.language));});
  const forced=new URLSearchParams(location.search).get('lang');
  if(forced==='en'){save('en');return;}
  const stored=read();
  if(locale==='en'&&stored&&stored!=='en'&&names[stored]){location.replace(url(stored));return;}
  if(locale!=='en'){save(locale);return;}
  if(stored)return;
  const dialog=document.createElement('dialog');dialog.className='language-dialog';dialog.setAttribute('aria-labelledby','language-welcome');
  dialog.innerHTML='<p>Crossgates Connect</p><h2 id="language-welcome">Which language would you like to use?</h2><p><span lang="fr">Choisissez votre langue.</span> <span lang="de">Wählen Sie Ihre Sprache.</span><br><span lang="sw">Chagua lugha.</span> <span lang="lg">Londa olulimi.</span></p><nav aria-label="Choose language"></nav><p>You can change your language at any time.</p><button type="button">Continue in English</button>';
  for(const [key,name] of Object.entries(names)){const a=document.createElement('a');a.href=url(key);a.lang=key;a.hreflang=key;a.textContent=name;a.addEventListener('click',()=>save(key));dialog.querySelector('nav').append(a);}
  dialog.querySelector('button').addEventListener('click',()=>dialog.close());
  dialog.addEventListener('close',()=>{save('en');dialog.remove();});
  document.body.append(dialog);if(dialog.showModal)dialog.showModal();else dialog.setAttribute('open','');
})();
