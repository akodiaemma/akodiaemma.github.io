'use strict';
// Public demonstration data. No live supplier record is exposed here.
const records = {
  "coffee": {
    "title": "Example African Coffee Supplier",
    "subtitle": "Green coffee · Uganda · Intended market: United Kingdom",
    "badge": "Fictional demonstration",
    "noticeTitle": "Fictional demonstration · no real supplier assessed",
    "notice": "All business information, dates, review notes and statuses in this coffee example are illustrative. No real supplier, document, product or shipment has been verified.",
    "description": "This demonstration shows how a supplier profile can bring available information, review notes and unresolved questions into one buyer-readable view.",
    "fields": [
      [
        "Product",
        "Green coffee — example"
      ],
      [
        "Country",
        "Uganda — example"
      ],
      [
        "Target market",
        "United Kingdom — example"
      ],
      [
        "Sample review date",
        "1 October 2026"
      ],
      [
        "Sample reviewer",
        "Fictional human reviewer"
      ],
      [
        "Overall position",
        "Follow-up needed"
      ]
    ],
    "noteTitle": "An organised profile can still contain important gaps.",
    "note": "In this example, business details have been compared with a supplied document and the product description checked for completeness. Origin and batch-handling records remain incomplete. No authenticity or product-quality confirmation is represented.",
    "evidenceDescription": "Open the illustrative records to understand the difference between a limited documentation review and a fact confirmed against an independent source.",
    "evidence": [
      {
        "title": "Business registration",
        "status": "Illustrative review",
        "group": "ok",
        "note": "Fictional company details compared with a fictional supplier-provided document for consistency. No issuing registry was consulted. Sample review date: 1 October 2026."
      },
      {
        "title": "Product information",
        "status": "Illustrative review",
        "group": "ok",
        "note": "Fictional product description checked for completeness. No physical inspection, laboratory test or buyer acceptance is represented."
      },
      {
        "title": "Origin and batch traceability",
        "status": "Needs review — example",
        "group": "followup",
        "note": "The illustrative batch reference DEMO-COFFEE-001 has no complete link to origin and handling records. GPS evidence is not supplied."
      },
      {
        "title": "Supporting documents",
        "status": "Missing items — example",
        "group": "followup",
        "note": "Further documents would be agreed for the business, product, intended market and buyer. This is not a definitive export-requirements list."
      }
    ],
    "nextDescription": "Illustrative next steps for the fictional supplier and its prospective buyer.",
    "next": [
      "Supplier: gather the missing origin and batch-handling records.",
      "Reviewer: assess the additional evidence within an agreed scope and record the source, reviewer and date.",
      "Buyer: clarify product specifications, sampling and independent checks before making a decision.",
      "Programme: use the visible gaps to target support and follow up on agreed actions."
    ]
  }
};
let activeRecord = 'coffee';
const tabs = Array.from(document.querySelectorAll('[role="tab"]'));
const search = document.getElementById('evidence-search');
const filter = document.getElementById('evidence-filter');
function setText(id,text){document.getElementById(id).textContent=text;}
function selectTab(name,focus=false){
 tabs.forEach(tab=>{const active=tab.getAttribute('aria-controls')===name;tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;document.getElementById(tab.getAttribute('aria-controls')).hidden=!active;if(active&&focus)tab.focus();});
}
function renderEvidence(){
 const all=records[activeRecord].evidence;
 const query=search.value.trim().toLowerCase();
 const shown=all.filter(item=>(filter.value==='all'||item.group===filter.value)&&[item.title,item.status,item.note].join(' ').toLowerCase().includes(query));
 const list=document.getElementById('evidence-list');list.replaceChildren();
 shown.forEach(item=>{
  const details=document.createElement('details');const summary=document.createElement('summary');const title=document.createElement('span');title.className='record-title';title.textContent=item.title;
  const status=document.createElement('span');status.className='status '+item.group;status.textContent=item.status;summary.append(title,status);
  const note=document.createElement('p');note.textContent=item.note;
  const source=document.createElement('p');const label=document.createElement('strong');label.textContent='Source: ';source.append(label,document.createTextNode('Fictional demonstration data; no real evidence supplied.'));
  details.append(summary,note,source);list.append(details);
 });
 setText('evidence-count',shown.length+' of '+all.length+' items shown');document.getElementById('empty-evidence').hidden=shown.length!==0;
}
function selectRecord(key){
 if(!Object.hasOwn(records,key))return;
 activeRecord=key;const record=records[key];
 document.querySelectorAll('[data-passport]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.passport===key)));
 setText('supplier-title',record.title);setText('supplier-subtitle',record.subtitle);setText('record-badge',record.badge);
 const notice=document.getElementById('source-notice');const strong=document.createElement('strong');strong.textContent=record.noticeTitle;notice.replaceChildren(strong,document.createTextNode(record.notice));
 setText('overview-description',record.description);setText('overview-note-title',record.noteTitle);setText('overview-note',record.note);
 const grid=document.getElementById('overview-grid');grid.replaceChildren();record.fields.forEach(([label,value])=>{const div=document.createElement('div');const dt=document.createElement('dt');const dd=document.createElement('dd');dt.textContent=label;dd.textContent=value;div.append(dt,dd);grid.append(div);});
 setText('evidence-description',record.evidenceDescription);setText('next-description',record.nextDescription);
 const next=document.getElementById('next-list');next.replaceChildren();record.next.forEach(text=>{const li=document.createElement('li');li.textContent=text;next.append(li);});
 document.getElementById('demo-document').hidden=false;
 setText('tab-document','Demo notes');search.value='';filter.value='all';renderEvidence();selectTab('overview');
}
document.querySelectorAll('[data-passport]').forEach(button=>button.addEventListener('click',()=>selectRecord(button.dataset.passport)));
tabs.forEach((tab,index)=>{
 tab.addEventListener('click',()=>selectTab(tab.getAttribute('aria-controls')));
 tab.addEventListener('keydown',event=>{let next=index;if(event.key==='ArrowRight')next=(index+1)%tabs.length;else if(event.key==='ArrowLeft')next=(index+tabs.length-1)%tabs.length;else if(event.key==='Home')next=0;else if(event.key==='End')next=tabs.length-1;else return;event.preventDefault();selectTab(tabs[next].getAttribute('aria-controls'),true);});
});
document.querySelectorAll('[data-go]').forEach(button=>button.addEventListener('click',()=>selectTab(button.dataset.go,true)));
search.addEventListener('input',renderEvidence);filter.addEventListener('change',renderEvidence);
selectRecord('coffee');
if(location.hash==='#document')selectTab('document');
