/* On-site STIV video viewer. Stream the existing STIV video from the public repository.
   Source is assigned only on user interaction, to avoid large initial page downloads. */
(function(){
  const dialog=document.getElementById('stiv-video-dialog');
  const video=document.getElementById('stiv-video-player');
  const open=document.querySelector('[data-open-stiv-video]');
  if(!dialog||!video||!open)return;
  const status=dialog.querySelector('.stiv-video-status');
  const close=dialog.querySelector('.stiv-video-close');
  const source=open.getAttribute('data-video-src');
  function reset(){video.pause();video.removeAttribute('src');video.load();if(status)status.dataset.visible='false';}
  function show(event){
    if(typeof dialog.showModal!=='function')return;
    event.preventDefault();
    if(status)status.dataset.visible='false';
    dialog.showModal();
    video.src=source;
    video.load();
    const p=video.play();
    if(p&&p.catch)p.catch(()=>{}); // autoplay can be blocked; native controls remain available
  }
  open.addEventListener('click',show);
  close.addEventListener('click',()=>dialog.close());
  dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close();});
  dialog.addEventListener('close',reset);
  video.addEventListener('error',()=>{if(status)status.dataset.visible='true';});
})();
