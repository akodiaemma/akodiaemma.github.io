'use strict';
(() => {
 const get=id=>document.getElementById(id);
 const write=(id,text)=>{get(id).textContent=text;};
 const mobile=document.querySelector('.mobile-nav');
 mobile.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{mobile.open=false;}));
 document.addEventListener('keydown',event=>{if(event.key==='Escape'&&mobile.open){mobile.open=false;mobile.querySelector('summary').focus();}});
 const chapters=[
  {title:'“I have coffee. How do I show a buyer?”',copy:'An example Ugandan supplier wants to reach a UK buyer. The product is ready to discuss. The evidence is scattered.',question:'The buyer asks: “What supports your claims?”',label:'THE STARTING POINT',evidence:'One product. Separate records.',identity:'Supplied',product:'Supplied',origin:'Missing',bottom:'The missing records still need to be gathered.',next:'See the gap'},
  {title:'“What am I missing?”',copy:'Crossgates helps organise the records. The missing origin and batch information becomes a clear next action.',question:'The supplier’s next step: gather the records that connect the coffee to its source.',label:'THE GAP IS VISIBLE',evidence:'Know what to prepare next.',identity:'Review pending',product:'Review pending',origin:'Action needed',bottom:'STIV guides preparation. Supplied records still need review.',next:'Follow the review'},
  {title:'“What has actually been checked?”',copy:'A human reviewer compares the business details with the supplied document and checks the product description for completeness.',question:'The conclusion stays specific: consistency checked, authenticity unconfirmed.',label:'A SCOPED REVIEW',evidence:'See what each check covers.',identity:'Consistency checked',product:'Completeness checked',origin:'Still missing',bottom:'This illustration includes no registry confirmation, lab test or site visit.',next:'See the Passport'},
  {title:'“Now we can ask better questions.”',copy:'The buyer sees the business information, review notes and remaining gaps together in one Trade Passport.',question:'The buyer decides which additional records, samples or checks are needed.',label:'THE BUYER VIEW',evidence:'A clearer starting point.',identity:'Review recorded',product:'Review recorded',origin:'Follow-up needed',bottom:'Sharing a profile does not guarantee buyer approval or a sale.',next:'Explore the example'}
 ];
 let current=0;
 function renderChapter(index){
  current=Math.max(0,Math.min(chapters.length-1,index));const c=chapters[current];
  document.querySelectorAll('[data-chapter]').forEach(button=>button.setAttribute('aria-pressed',String(Number(button.dataset.chapter)===current)));
  write('chapter-count','Chapter 0'+(current+1)+' / 04');
  ['title','copy','question'].forEach(key=>write('chapter-'+key,c[key]));
  write('evidence-label',c.label);write('evidence-title',c.evidence);write('identity-status',c.identity);write('product-status',c.product);write('origin-status',c.origin);write('evidence-bottom',c.bottom);
  document.querySelector('.evidence-records').dataset.scene=String(current);
  get('chapter-back').disabled=current===0;get('chapter-next').hidden=current===3;get('chapter-explore').hidden=current!==3;write('chapter-next',c.next);
 }
 document.querySelectorAll('[data-chapter]').forEach(button=>button.addEventListener('click',()=>renderChapter(Number(button.dataset.chapter))));
 get('chapter-back').addEventListener('click',()=>renderChapter(current-1));
 get('chapter-next').addEventListener('click',()=>{renderChapter(current+1);if(current===3)get('chapter-explore').focus({preventScroll:true});});
 const notes=[{"title": "Who is the supplier?", "copy": "The fictional profile brings the business, green-coffee product and intended market into one place. These example details do not establish a real supplier’s identity."}, {"title": "How current is the review?", "copy": "The sample review date and fictional reviewer show where a real assessment would record when, by whom and within what scope a check was made."}, {"title": "What supports the claims?", "copy": "The demonstration separates a limited consistency review from missing origin and batch records. No registry confirmation or product testing is represented."}, {"title": "What still needs to happen?", "copy": "The supplier needs origin and batch-handling records. The buyer still needs to clarify specifications, samples and any independent checks."}];
 document.querySelectorAll('[data-marker]').forEach(button=>button.addEventListener('click',()=>{
  const index=Number(button.dataset.marker);document.querySelectorAll('[data-marker]').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.marker)===index)));
  write('annotation-title',notes[index].title);write('annotation-copy',notes[index].copy);
 }));
 const events=[
  {src:'img/excel-food-expo.webp',width:1086,height:1448,alt:'Doris Beth Atigo at a coffee exhibition stand during a food expo at ExCeL London.',title:'Food expo · ExCeL London',caption:"Gathering market information at ExCeL London and speaking with buyers about what they need from suppliers, as part of the research shaping Crossgates.",credit:''},
  {src:'img/uk-africa-summit.webp',width:2048,height:1366,alt:'Doris Beth Atigo in a red suit among delegates at the UK–Africa Investment Summit.',title:'UK–Africa Investment Summit',caption:"Representing Crossgates and promoting Uganda’s trade potential to an international audience, with conversations about bringing Ugandan businesses to global markets.",credit:'Photograph: © thepromotaAfrica'},
  {src:'img/international-coffee-day.webp',width:1448,height:1086,alt:'Attendees in conversation beside a coffee machine at an International Coffee Day gathering.',title:'International Coffee Day',caption:"Joining Uganda’s coffee community in London for International Coffee Day and conversations around coffee and international trade.",credit:''},
  {src:'img/spitalfields-market.webp',width:1152,height:1536,alt:'Doris Beth Atigo in conversation beside stacked fresh-produce boxes at Spitalfields Market.',title:'Spitalfields Market',caption:"Listening to wholesale buyers and traders about their sourcing needs, the information they expect from suppliers and the practical requirements of the UK market.",credit:''}
 ];
 document.querySelectorAll('[data-event]').forEach(button=>button.addEventListener('click',()=>{
  const index=Number(button.dataset.event),item=events[index];document.querySelectorAll('[data-event]').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.event)===index)));
  const photo=get('event-image');photo.src=item.src;photo.alt=item.alt;photo.width=item.width;photo.height=item.height;
  write('event-title',item.title);write('event-caption',item.caption);write('event-credit',item.credit);get('event-credit').hidden=!item.credit;
 }));
 const roles={supplier:{title:'Build your trade-ready profile.',copy:'Bring your records. Understand the gaps. Prepare a clearer introduction to buyers.',action:'Discuss my business'},buyer:{title:'See what sits behind a supplier’s claims.',copy:'Explore the information, review notes and outstanding questions before deciding your next checks.',action:'Discuss a supplier review'},institution:{title:'See where your businesses need support.',copy:'Understand evidence gaps across your programme and focus readiness support where it is needed.',action:'Discuss my programme'}};
 function selectRole(role){
  if(!roles[role]||!get('audience-action'))return;document.querySelectorAll('[data-role]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.role===role)));
  write('audience-title',roles[role].title);write('audience-copy',roles[role].copy);write('audience-action',roles[role].action);get('audience-action').dataset.audience=role;
 }
 document.querySelectorAll('[data-role]').forEach(button=>button.addEventListener('click',()=>selectRole(button.dataset.role)));
 const roleHashes={'#suppliers':'supplier','#buyers':'buyer','#institutions':'institution'};
 const readRole=()=>{const role=roleHashes[location.hash]||new URLSearchParams(location.search).get('audience');if(role)selectRole(role);};
 window.addEventListener('hashchange',readRole);readRole();
})();
