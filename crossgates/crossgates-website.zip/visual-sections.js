'use strict';
(() => {
 const get = id => document.getElementById(id);
 const write = (id, value) => { get(id).textContent = value; };
 const recordViews = {
  scattered: {mode:'SEPARATE RECORDS',heading:'What does the buyer still need to know?',description:'Information sits in different places. The buyer must work out what each item supports and which evidence is absent.',footnote:'Select “One organised profile” to see how the same information can be presented.'},
  organised: {mode:'ONE ORGANISED PROFILE',heading:'The evidence and its gaps are visible together.',description:'The same supplied records are arranged by the questions a buyer needs to ask. Missing evidence stays visible.',footnote:'Organisation is useful progress. It does not authenticate the documents or fill the missing evidence.'}
 };
 document.querySelectorAll('[data-record-view]').forEach(button => button.addEventListener('click', () => {
  const key = button.dataset.recordView; const record = recordViews[key];
  document.querySelectorAll('[data-record-view]').forEach(item => item.setAttribute('aria-pressed', String(item.dataset.recordView === key)));
  document.querySelector('.record-comparison').dataset.view = key;
  write('record-mode',record.mode);write('record-heading',record.heading);write('record-description',record.description);write('record-footnote',record.footnote);
  get('record-summary').hidden = key !== 'organised';
 }));
 const stages = [
  {kicker:'Step 01 / Supply information',title:'Start with what you have.',description:'The fictional supplier brings a business registration document and a green-coffee description. The profile records Uganda as the country and the UK as the intended market.',takeaway:'Starting point: an initial profile and the records already available.',view:'Initial supplier profile',identity:'Supplied',product:'Supplied',trace:'Not yet described',attention:false,actionLabel:'Next useful question',action:'Which records link the coffee to its origin and handling history?'},
  {kicker:'Step 02 / Find the gaps',title:'Turn missing information into an action.',description:'The coffee’s origin and batch-handling links are incomplete. The gap is made visible so the supplier knows what to gather next.',takeaway:'Next action: collect origin and batch records before relying on a traceability claim.',view:'Evidence gaps identified',identity:'Supplied · review pending',product:'Supplied · review pending',trace:'Missing supporting records',attention:true,actionLabel:'Supplier follow-up',action:'Gather the records connecting the batch to its origin and handling.'},
  {kicker:'Step 03 / Review evidence',title:'Show what the check actually covers.',description:'In the illustration, a human reviewer compares the business details with the supplied document and checks the product description for completeness. The source, date and limits are recorded.',takeaway:'A limited documentation review does not establish authenticity or product quality.',view:'Illustrative review recorded',identity:'Consistency reviewed',product:'Completeness reviewed',trace:'Still needs evidence',attention:true,actionLabel:'Scope of this example',action:'No registry confirmation, laboratory test or physical inspection is represented.'},
  {kicker:'Step 04 / Buyer view',title:'Give the buyer a clearer decision point.',description:'The example buyer view brings the information, review scope and outstanding questions together. The buyer can decide which additional evidence, samples or checks they need.',takeaway:'Outcome: a clearer conversation, with unresolved gaps still visible.',view:'Illustrative buyer view',identity:'Consistency reviewed',product:'Completeness reviewed',trace:'Follow-up required',attention:true,actionLabel:'Buyer’s next step',action:'Ask for missing records and agree any further checks before deciding whether to proceed.'}
 ];
 let currentStage = 0;
 function renderStage(index){
  currentStage = Math.max(0,Math.min(stages.length-1,index));const stage=stages[currentStage];
  document.querySelectorAll('[data-stage]').forEach(button=>button.setAttribute('aria-pressed',String(Number(button.dataset.stage)===currentStage)));
  ['kicker','title','description','takeaway','view','identity','product','trace','action'].forEach(key=>write('stage-'+key,stage[key]));
  write('stage-action-label',stage.actionLabel);get('stage-trace-row').classList.toggle('attention',stage.attention);
  get('stage-back').disabled=currentStage===0;get('stage-next').disabled=currentStage===stages.length-1;
  get('stage-next').textContent=currentStage===stages.length-1?'Final step':'Next step';
 }
 document.querySelectorAll('[data-stage]').forEach(button=>button.addEventListener('click',()=>renderStage(Number(button.dataset.stage))));
 get('stage-back').addEventListener('click',()=>renderStage(currentStage-1));get('stage-next').addEventListener('click',()=>renderStage(currentStage+1));
 renderStage(0);get('journey-interactive').hidden=false;get('journey-static').hidden=true;
 const annotations=[{"title": "Who is the supplier?", "copy": "The fictional profile brings the business, green-coffee product and intended market into one place. These example details do not establish a real supplier’s identity.", "kicker": "01 / Supplier profile", "question": "Ask: what evidence supports the profile?"}, {"title": "How current is the review?", "copy": "The sample review date and fictional reviewer show where a real assessment would record when, by whom and within what scope a check was made.", "kicker": "02 / Review details", "question": "Ask: what was reviewed, by whom and when?"}, {"title": "What supports the claims?", "copy": "The demonstration separates a limited consistency review from missing origin and batch records. No registry confirmation or product testing is represented.", "kicker": "03 / Evidence status", "question": "Ask: what is independently confirmed and what remains open?"}, {"title": "What still needs to happen?", "copy": "The supplier needs origin and batch-handling records. The buyer still needs to clarify specifications, samples and any independent checks.", "kicker": "04 / Next actions", "question": "Ask: who owns each next step?"}];
 document.querySelectorAll('[data-marker]').forEach(button=>button.addEventListener('click',()=>{
  const index=Number(button.dataset.marker);const note=annotations[index];
  document.querySelectorAll('[data-marker]').forEach(item=>item.setAttribute('aria-pressed',String(Number(item.dataset.marker)===index)));
  ['kicker','title','copy','question'].forEach(key=>write('annotation-'+key,note[key]));
 }));
 const trail=[
  {label:'Supplier-provided source',title:'A registration document is supplied.',copy:'In this fictional example, the reviewer receives a document from the supplier. The issuing registry has not been contacted.',limit:'Receiving a document does not establish its authenticity or current validity.'},
  {label:'Limited consistency check',title:'Company details are compared.',copy:'The reviewer compares the company details entered in the example profile with the details on the supplied document. The scope is recorded as document consistency only.',limit:'A match between two sets of details does not prove that the source document is genuine.'},
  {label:'Scoped review conclusion',title:'Consistency reviewed. Authenticity unconfirmed.',copy:'The useful conclusion is specific: the compared details are consistent in this illustration. The source, reviewer, review date and unresolved question belong alongside the status.',limit:'The review does not certify the product, approve an export or guarantee a transaction.'}
 ];
 document.querySelectorAll('[data-trail]').forEach(button=>button.addEventListener('click',()=>{
  const index=Number(button.dataset.trail);const item=trail[index];
  document.querySelectorAll('[data-trail]').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.trail)===index)));
  ['label','title','copy','limit'].forEach(key=>write('trail-'+key,item[key]));
 }));
})();
