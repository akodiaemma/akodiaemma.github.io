'use strict';
(() => {
 const mobile=document.querySelector('.mobile-nav');
 mobile.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{mobile.open=false;}));
 document.addEventListener('keydown',event=>{if(event.key==='Escape'&&mobile.open){mobile.open=false;mobile.querySelector('summary').focus();}});
 const panels=[...document.querySelectorAll('.work-panel')];
 const links=[...document.querySelectorAll('[data-work]')];
 const valid=new Set(panels.map(panel=>panel.id));
 function show(key,focus=false){
  if(!valid.has(key))key='suppliers';
  panels.forEach(panel=>{panel.hidden=panel.id!==key;if(panel.hidden)panel.querySelectorAll('video').forEach(video=>video.pause());});
  links.forEach(link=>{if(link.dataset.work===key)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');});
  if(focus){const heading=document.querySelector('#'+key+' h2');heading.focus({preventScroll:true});heading.scrollIntoView({block:'start',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});}
 }
 links.forEach(link=>link.addEventListener('click',event=>{
  event.preventDefault();const key=link.dataset.work;
  if(location.hash!=='#'+key)history.pushState(null,'','#'+key);
  show(key,true);
 }));
 window.addEventListener('hashchange',()=>{const key=location.hash.slice(1);if(valid.has(key))show(key);else if(!key)show('suppliers');});
 show(location.hash.slice(1));
 document.querySelectorAll('.work-films').forEach(detail=>detail.addEventListener('toggle',()=>{if(!detail.open)detail.querySelectorAll('video').forEach(video=>video.pause());}));
 document.querySelectorAll('video').forEach(video=>video.addEventListener('play',()=>document.querySelectorAll('video').forEach(other=>{if(other!==video)other.pause();})));
})();
